# Step-by-step: run ThreadMind and submit to Graph Hacks

This guide assumes Windows 11 and PowerShell. The application is also compatible with macOS/Linux using equivalent shell commands.

## Part A — Prepare your computer

1. Install **Python 3.10 or newer** and confirm from PowerShell:
   ```powershell
   py --version
   ```
2. Install **Git** and confirm:
   ```powershell
   git --version
   ```
3. Install and start **Docker Desktop**, then confirm both commands work:
   ```powershell
   docker --version
   docker compose version
   ```
   If `docker` is not recognized, restart PowerShell after installing Docker Desktop and ensure Docker Desktop is running.
4. Download `threadmind-graph-hacks.zip` from the provided project link and extract it. Open the extracted `threadmind-graph-hacks` folder; it should contain `app.py`, `graph_service.py`, `agent.py`, `docker-compose.yml`, and `README.md` directly.

## Part B — Start the actual app and FalkorDB

1. In File Explorer, open the extracted project folder.
2. Click the address bar, type `powershell`, and press Enter. This opens PowerShell in the project directory.
3. Copy the example environment file:
   ```powershell
   Copy-Item .env.example .env
   ```
4. Leave `OPENAI_API_KEY` blank for the first run. Graph-grounded deterministic mode does not require an LLM key.
5. Build and start the entire stack:
   ```powershell
   docker compose up --build
   ```
6. Wait until the application logs show Streamlit has started. Open **http://localhost:8501**. FalkorDB Browser, if you want to inspect queries visually, is at **http://localhost:3000**.
7. The app's sidebar should show **Connected**. If not, check the PowerShell logs, confirm Docker Desktop is running, and use the error message shown by ThreadMind. Do not start recording until this is fixed.

To stop the stack later, press `Ctrl+C` in the terminal and run `docker compose down` in another PowerShell window in the project folder. Avoid `docker compose down -v` unless you intentionally want to delete the saved demo graph.

## Part C — Prove the core workflow

Use the synthetic demo data that ThreadMind creates on first launch. The initial expected state is:

- T1 — Define the project scope: `done`
- T2 — Implement graph-backed task reasoning: `in_progress`
- T3 — Build the agent interface: `todo`
- T4 — Create a reproducible demo: `todo`
- T5 — Prepare synthetic example data: `done`
- T6 — Record and submit the demo: `todo`

In **Ask ThreadMind**, test these prompts one by one:

1. `What should I work on next?` Expected: T2 is recommended because T1 is done and T2 is in progress.
2. `What is blocked and why?` Expected: the answer names unfinished prerequisite paths. T3 depends on T2; T4 depends on T3; T6 depends on T4 and T5.
3. `What gets unblocked if T2 is done?` Expected: T3 is identified as immediately ready (its only prerequisite is T2). T4 and T6 appear as downstream impact but are not said to be immediately ready because they have other unfinished prerequisites in their chains.
4. Open **Task board** and change T2 to `done`. Return to Ask ThreadMind and ask again what to do next. Expected: T3 becomes eligible after the graph status changes.
5. Open **Decision memory**. Add a short fictional decision and link it to T3 or T4. Return to the agent and ask `What decisions should I remember?` Expected: the new decision is retrieved by following `AFFECTS` edges.
6. Open **Graph evidence**. Show the actual `DEPENDS_ON` and `AFFECTS` rows. Explain that the recommendations depend on these relationships stored in FalkorDB.

### Run the live graph smoke test

Open a second PowerShell window in the project directory while Docker Compose is running. Run:

```powershell
py -m pip install -r requirements.txt
py scripts/live_smoke.py --reset
```

**Warning:** `--reset` deletes every node in the configured graph and recreates the synthetic example. Use this only when the `threadmind` graph contains disposable demo data. The command should print five `PASS` lines and finish with `All 5 live FalkorDB smoke checks passed.` If any check fails, do not claim the live integration is verified; copy the error and fix it first.

The Python unit tests are separate from this live check:

```powershell
py -m pytest -q
```

Expected in the supplied archive: `9 passed`. These are lightweight tests of answer routing/query construction; they do not replace the live smoke test or a manual UI test.

## Part D — Create a public GitHub repository

1. Sign in to GitHub in your browser and create a **new public repository** named `threadmind-graph-hacks`.
2. Do **not** initialize it with a README, `.gitignore`, or license; those files already exist in the project.
3. Back in PowerShell, ensure you are in the folder where `app.py` is located. Run:
   ```powershell
   git init
   git add .
   git commit -m "Build ThreadMind explainable graph planning agent"
   git branch -M main
   git remote add origin https://github.com/YOUR_GITHUB_USERNAME/threadmind-graph-hacks.git
   git push -u origin main
   ```
   Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username. Git may open a browser to authenticate. If `git commit` asks for your identity, configure `git config --global user.name` and `git config --global user.email` with your own details, then repeat the commit.
4. If `git remote add origin` says the remote already exists, run `git remote -v`; do not blindly add a second remote.
5. Open your new repository in a private/incognito browser window. Verify the README renders and the files are public. Make sure `.env` is not committed and no API key appears in source/history.

## Part E — Record the real demo video

1. Reset the graph to the sample state from the app's sidebar before recording. Confirm all prompts above work again.
2. Use OBS Studio (or another screen recorder) to capture the browser with the app running at `http://localhost:8501`. Record your voice explaining what the graph is doing. Do not use a mockup or record before the app is working.
3. Aim for 2–3 minutes. Follow `DEMO_SCRIPT.md`, starting with the core result, then show the blocker path, downstream impact, status update, decision recall, and graph evidence.
4. Upload to YouTube as **Unlisted** or **Public**. Open the link in a private/incognito window to confirm it loads without sign-in. Copy the actual `youtu.be` or watch URL.

## Part F — Complete the WeMakeDevs form

Use `SUBMISSION_FIELDS.md` for draft responses. On the submission form:

- **Project title:** ThreadMind — Graph-Powered Project Teammate
- **Description:** use the prepared description in `SUBMISSION_FIELDS.md`.
- **Track:** select **Agents That Act on Connected Data**.
- **Repository:** paste the real public GitHub URL after confirming it opens.
- **Demo video:** paste the real public/unlisted YouTube URL.
- **Live demo/deployment:** do not invent a URL. The official rules allow complete local setup instructions when there is no live deployment; the README contains those instructions. If the field permits explanatory text, state that Docker Compose local setup is provided in the repository.
- **How did you use FalkorDB?:** use the prepared answer from `SUBMISSION_FIELDS.md`.
- **Blog link:** leave blank unless you actually publish a blog post.
- **FalkorDB feedback:** use the two prepared answers, and edit them so they reflect your own experience using the product.

Review every required field and submit before the deadline. Save a screenshot or confirmation of successful submission for your records.

## Part G — Be ready to explain the design

Be able to explain these points in your own words:

1. `Project`, `Task`, and `Decision` are node labels. `HAS_TASK`, `DEPENDS_ON`, and `AFFECTS` are edge types.
2. The direction of `(Task)-[:DEPENDS_ON]->(Task)` means “the first task requires the second task first.”
3. The readiness query filters for active tasks whose direct prerequisites are all `done`.
4. The blocker query traverses `DEPENDS_ON*1..` to find unfinished prerequisites at any depth.
5. The impact query traverses dependency paths in reverse and separately checks whether a downstream task would be ready immediately or still has unfinished prerequisites.
6. The optional LLM does not supply the task state or graph edges; FalkorDB is the source of truth. With no API key, deterministic graph-grounded answers still work.
7. The demo data is synthetic. User need, time saved, and production reliability have not been proven by the included automated tests.

## Stop/go checklist

Do not submit until every required line below is checked.

- [ ] App actually starts and sidebar shows FalkorDB connected.
- [ ] Next-task prompt gives an evidence-backed recommendation.
- [ ] Blocker question names the correct dependency chain.
- [ ] Downstream-impact answer distinguishes immediate readiness from later impact.
- [ ] Task state update persists and changes the next recommendation.
- [ ] New decision persists and is retrieved via an `AFFECTS` edge.
- [ ] Live smoke test passes.
- [ ] Public GitHub repository opens in private/incognito window.
- [ ] YouTube video opens in private/incognito window.
- [ ] AI-assistance disclosure is included.
- [ ] Submission form has the correct track and contains no placeholder links.
