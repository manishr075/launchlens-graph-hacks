# ThreadMind 🧠

**Know what to do next—and what your work will unblock—with an explainable project graph.**

Track: **Agents That Act on Connected Data**

> ThreadMind keeps project context in FalkorDB, not in a separate JSON file. Its readiness planner and blocker explainer traverse `DEPENDS_ON` paths; decision recall follows `AFFECTS` edges. Removing FalkorDB removes these core behaviors.

## The problem

Project details get spread across chats, task lists, and meeting notes. A conventional list can say a task is open, but it cannot reliably answer *why* it is blocked, which upstream task is responsible, or which past decision explains the current approach. ThreadMind represents tasks, prerequisites, and decisions as a connected graph and returns recommendations with inspectable graph evidence.

## Implemented behavior (live verification required before submission)

The source implements the following end-to-end behaviors, but the full app was not run against a live FalkorDB instance in the environment used to prepare this archive. Run the live smoke test and manual UI checklist before describing these behaviors as verified.

- **Graph-based next-step planning:** finds active tasks whose prerequisite tasks are all done, then ranks the eligible work by in-progress state and priority.
- **Dependency-chain blocker tracing:** traverses one or more `DEPENDS_ON` edges to identify unfinished prerequisites upstream.
- **Downstream impact analysis:** traverses those same edges in reverse to show which unfinished tasks depend on a selected task, how many hops away they are, and which connected decisions affect the downstream work.
- **Persistent decision memory:** stores `Decision` nodes and connects them to impacted tasks with `AFFECTS`; questions about remembered decisions retrieve those links.
- **Task updates and creation:** modify task state in FalkorDB; status cannot be set to done while an upstream prerequisite is unfinished.
- **Inspectability:** the interface shows the dependency and decision edges that the agent uses.
- **LLM-optional answers:** without an API key, deterministic graph-grounded answers work locally. With `OPENAI_API_KEY`, the LLM can synthesize an answer from the retrieved graph evidence; the graph remains the source of truth.
- **Synthetic starter graph:** first launch creates a fictional example automatically. It does not use any private or restricted data.

## Quick start (local)

For a Windows-first step-by-step walkthrough including verification, GitHub publishing, video recording, and submission fields, see [`SETUP_AND_SUBMIT_GUIDE.md`](SETUP_AND_SUBMIT_GUIDE.md).

Prerequisites: Docker with Compose, Python 3.10+, and a browser.

### Option A — recommended: start the full stack with Docker Compose

```bash
git clone <your-public-repository-url>
cd threadmind-graph-hacks
cp .env.example .env
# Optional: add OPENAI_API_KEY to .env; leave it blank for offline deterministic answers.
docker compose up --build
```

Then open:

- ThreadMind app: http://localhost:8501
- FalkorDB Browser: http://localhost:3000

The graph data is stored in the `falkordb_data` Docker volume. To stop the stack, run `docker compose down`. To also remove the stored demo graph, run `docker compose down -v` (this deletes the Docker volume).

### Option B — run the app on your computer and FalkorDB in Docker

Terminal 1 — start FalkorDB using the official image and ports:

```bash
docker run --name threadmind-falkordb -p 6379:6379 -p 3000:3000 -d falkordb/falkordb:latest
```

Terminal 2 — install Python dependencies and start the app:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
streamlit run app.py
```

On Windows, copy `.env.example` to `.env` using File Explorer if `cp` is unavailable. If your machine already uses port 6379 or 8501, change the exposed port and matching environment variables.

### Optional LLM synthesis

Copy `.env.example` to `.env`, set `OPENAI_API_KEY`, and optionally set `OPENAI_MODEL`. Never commit `.env` or publish API keys. The project works without this key; an OpenAI call is only used after live graph evidence has been retrieved.

## First demo walkthrough

1. Open ThreadMind and confirm that the sidebar says FalkorDB is connected.
2. In **Ask ThreadMind**, click **What should I work on next?**. The answer should recommend **Implement graph-backed task reasoning** because its prerequisite **Define the project scope** is done.
3. Ask **What is blocked and why?**. The dependency traversal should show that **Build the agent interface** waits on unfinished graph reasoning, and downstream work is consequently affected.
4. Ask **What gets unblocked if T2 is done?**. The agent reverse-traverses `DEPENDS_ON` paths to show downstream tasks and related decisions.
5. Open **Task board** and mark **Implement graph-backed task reasoning** as **Done**. The interface persists the change into FalkorDB; dependent tasks can now become ready.
6. Open **Decision memory** and add a decision linked to one or more tasks. Return to the agent and ask **What decisions should I remember?**. The response should retrieve the decision through `AFFECTS` relationships.
7. Open **Graph evidence** and show both edge types. Explain that planning, blocker tracing, and impact analysis depend on those edges.

If a behavior does not match this walkthrough, fix and rerun it before recording the submission video. Do not record an unverified demo.

## Graph data model

```mermaid
graph TD
  P[Project] -->|HAS_TASK| T1[Task]
  T1 -->|DEPENDS_ON| T2[Prerequisite Task]
  D[Decision] -->|AFFECTS| T1
```

### Node labels and properties

| Node | Main properties | Purpose |
|---|---|---|
| `Project` | `id`, `name`, `description`, `created_at` | Groups tasks for a project |
| `Task` | `id`, `title`, `description`, `status`, `priority`, `owner`, `due_date`, `updated_at` | Work item and state |
| `Decision` | `id`, `title`, `details`, `created_at` | Durable memory of a decision |

### Relationships

- `(Project)-[:HAS_TASK]->(Task)` — tasks associated with a project.
- `(Task)-[:DEPENDS_ON]->(Task)` — **the source task needs the target prerequisite to be done first**. For example, `(Build UI)-[:DEPENDS_ON]->(Implement graph queries)`.
- `(Decision)-[:AFFECTS]->(Task)` — decisions associated with impacted tasks. This allows later sessions to retrieve context relevant to the task.

Task and decision information is persisted directly in FalkorDB. Streamlit session state holds only transient chat display data, not a second project database.

## Core graph queries

The full set is in [`queries.cypher`](queries.cypher). The most important query uses FalkorDB relationships to find active tasks with no unfinished prerequisite:

```cypher
MATCH (p:Project {id: $project_id})-[:HAS_TASK]->(t:Task)
WHERE t.status IN ['todo', 'in_progress']
OPTIONAL MATCH (t)-[:DEPENDS_ON]->(dep:Task)
WITH t, collect(dep) AS deps
WHERE all(dep IN deps WHERE dep.status = 'done')
RETURN t.id, t.title, t.status, t.priority, size(deps) AS dependency_count;
```

Blocker discovery traverses paths, not just immediate edges:

```cypher
MATCH (p:Project {id: $project_id})-[:HAS_TASK]->(t:Task)
WHERE t.status IN ['todo', 'in_progress']
MATCH (t)-[:DEPENDS_ON*1..]->(dep:Task)
WHERE dep.status <> 'done'
RETURN t.id, t.title, collect(DISTINCT dep.title) AS blockers;
```

Downstream impact analysis reverses the dependency traversal. It finds unfinished tasks whose prerequisite path leads to a selected task, then attaches related decision memories:

```cypher
MATCH path=(downstream:Task)-[:DEPENDS_ON*1..]->(target:Task {id: $task_id})
WHERE downstream.status <> 'done' AND downstream.id <> target.id
WITH downstream, target, min(length(path)) AS distance
OPTIONAL MATCH (downstream)-[:DEPENDS_ON]->(direct_dep:Task)
WITH downstream, target, distance, collect(direct_dep) AS direct_deps
WITH downstream, target, distance,
     all(dep IN direct_deps WHERE dep.status = 'done' OR dep.id = target.id) AS ready_if_target_done
OPTIONAL MATCH (d:Decision)-[:AFFECTS]->(downstream)
RETURN downstream.id, downstream.title, downstream.status, distance,
       ready_if_target_done, collect(DISTINCT d.title) AS linked_decisions
ORDER BY distance, downstream.id;
```

Decision recall follows the decision-to-task relationship:

```cypher
MATCH (d:Decision)-[:AFFECTS]->(t:Task)
RETURN d.title, d.details, collect(DISTINCT t.title) AS affected_tasks;
```

## Architecture

```mermaid
flowchart LR
  U[User] --> UI[Streamlit UI]
  UI --> A[ThreadMind agent / intent router]
  A --> Q[Cypher graph queries]
  Q <--> F[(FalkorDB graph)]
  A -. optional evidence synthesis .-> L[OpenAI API]
  F --> E[Inspectible evidence shown to user]
```

- `app.py`: UI, task forms, graph inspection, and user interactions.
- `graph_service.py`: FalkorDB client, data model, seed records, and Cypher queries.
- `agent.py`: question routing, grounded deterministic answers, and optional LLM synthesis.
- `queries.cypher`: reviewable queries used by readiness, blocker tracing, downstream impact, decision recall, and graph inspection.

## Run a live FalkorDB smoke test

After starting FalkorDB and installing the Python dependencies, run the smoke test against the configured `threadmind` graph:

```bash
python scripts/live_smoke.py --reset
```

**Warning:** `--reset` deletes all nodes in the configured graph before recreating the fictional sample. Use it only when the graph contains disposable ThreadMind demo data. The script checks the ready-task query, multi-hop blocker tracing, downstream impact traversal, and persistent decision links against known sample outcomes. It is a live integration check—not a substitute for testing the full UI.

## Validation checklist

- [ ] `docker compose up --build` starts without errors.
- [ ] The app can connect to FalkorDB and creates the sample graph only if the graph is empty.
- [ ] `python scripts/live_smoke.py --reset` passes all five live checks.
- [ ] The “next task” answer is based on graph dependency state.
- [ ] An unfinished upstream task is visible in the blocker explanation.
- [ ] The impact prompt lists downstream tasks at multiple dependency depths and associated decision memory.
- [ ] Updating a prerequisite changes which tasks are ready.
- [ ] Adding a decision creates `AFFECTS` edges and later retrieves that decision.
- [ ] The README setup works from a fresh clone.
- [ ] The video is publicly accessible or unlisted, and the public repository URL is correct.

## AI assistance disclosure

AI coding assistance was used to scaffold and document this project. Before submission, the participant should run the app, review and understand each component, verify the Cypher behavior against a live FalkorDB instance, fix any issues, and make meaningful original improvements. The submitted implementation and demo must reflect work the participant can explain. Do not claim a test passed unless you ran it.

## Tech references

- [FalkorDB Getting Started](https://docs.falkordb.com/getting-started/)
- [Official FalkorDB Python client](https://github.com/FalkorDB/falkordb-py)
- [Streamlit documentation](https://docs.streamlit.io/)
