# Graph Hacks submission form — draft answers

Copy these after the public repository and demo video are actually available. Replace every placeholder first; do not submit fake URLs.

## Project title (required)

ThreadMind — Graph-Powered Project Teammate

## Description: problem and audience (required)

Projects lose critical context across task lists, chats, and meeting notes. ThreadMind helps student project teams and small engineering teams decide what to do next and understand what their work will unblock. FalkorDB stores task state, prerequisite edges, and decision memory. Cypher queries identify ready work, trace multi-hop blockers, and reverse-traverse dependencies to reveal downstream tasks affected by a completion, including associated decisions. The UI lets users update tasks and record decisions; subsequent answers reflect the changed graph. The prototype uses synthetic data and is designed to run without an LLM key, with optional LLM synthesis limited to retrieved graph evidence. Verify the live setup and workflow before submission.

## Track (required)

Select: **Agents That Act on Connected Data**

## Repository (required)

`https://github.com/YOUR_GITHUB_USERNAME/threadmind-graph-hacks`

Replace `YOUR_GITHUB_USERNAME` with the real account, create the public repository, and push this source before submitting.

## Demo video (required)

`https://youtu.be/REPLACE_WITH_YOUR_UNLISTED_OR_PUBLIC_VIDEO_ID`

Replace with a real public or unlisted YouTube video. Follow [`DEMO_SCRIPT.md`](DEMO_SCRIPT.md) and record a verified local run.

## Live demo or deployment

If there is no live deployment, use the local setup option accepted by the rules. This project provides a complete Docker Compose setup in `README.md`. If you publish a live app, paste its real public URL here.

## How did you use FalkorDB? (required)

FalkorDB is the system of record for every project task, dependency edge, and decision-memory edge. The Python service writes and reads `Project`, `Task`, and `Decision` nodes plus `HAS_TASK`, `DEPENDS_ON`, and `AFFECTS` relationships. A parameterized Cypher readiness query recommends active tasks whose prerequisites are complete. Variable-length dependency traversals reveal unfinished upstream blockers and, in reverse, downstream tasks that could be unblocked by completing a selected task. The impact query also connects those downstream tasks to relevant decision memories. Status updates and new decisions are persisted in FalkorDB. The app has no parallel task database, so removing FalkorDB removes its core planning and impact-analysis behaviors.

## Blog link (optional)

Leave blank unless you publish a real blog post. The submission project does not require inventing a URL.

## Feedback: what did you like about FalkorDB? (required)

The Cypher graph model made it straightforward to express project dependencies and trace blockers across multiple relationship hops. The Python client also makes graph queries easy to integrate into a small interactive application. I especially like that the important reasoning can live in queryable graph relationships instead of being hidden in frontend-only logic.

## Feedback: what improvements would you like to see in FalkorDB? (required)

More end-to-end agent examples that combine persistent memory, multi-hop reasoning, and state changes would help new builders move from the first graph query to a useful application faster. Clear, copyable troubleshooting examples for common local Docker/client connection issues and unsupported Cypher patterns would also improve the beginner experience.
