# Demo video script (2–3 minutes)

**Track:** Agents That Act on Connected Data.

**Important:** record the real application after testing it locally. Do not present this script as proof of a run that did not happen.

## 0:00–0:20 — Problem

“Project tools store tasks, but the missing piece is connected context: why a task is blocked and which earlier decision affects it. ThreadMind models tasks and decisions as nodes and uses FalkorDB relationships to reason over them.”

## 0:20–0:55 — Show graph-grounded planning

Open the app and ask “What should I work on next?” Show the recommended task and its explanation. Then open Graph evidence and point at `DEPENDS_ON`. Explain that readiness is computed by a Cypher query in FalkorDB, not from a hard-coded answer.

## 0:55–1:25 — Show a multi-hop blocker

Ask “What is blocked and why?” Highlight a task whose prerequisite chain includes an unfinished upstream task. Explain that `[:DEPENDS_ON*1..]` traverses across multiple dependency edges.

## 1:25–1:50 — Show downstream impact

Ask “What gets unblocked if T2 is done?” Show the tasks reached by reverse traversal and the related decision links. Point out that the result depends on graph relationships, not keyword matching.

## 1:50–2:15 — Show memory between interactions

Add a decision in Decision memory and link it to a task. Ask “What decisions should I remember?” Show the answer and the `AFFECTS` edge. Refresh the browser if you want to demonstrate that the decision remains in the database.

## 2:15–2:35 — Show state changes

Mark an eligible prerequisite task as done. Return to the next-task prompt and demonstrate that the recommended work changes because the graph changed.

## 2:35–2:55 — Close

“FalkorDB is the source of truth for task state, dependencies, and decision links. ThreadMind not only identifies blockers; it traces downstream impact and makes the evidence inspectable. The project includes the model, Cypher queries, setup instructions, and an optional LLM layer that only synthesizes retrieved graph evidence.”
