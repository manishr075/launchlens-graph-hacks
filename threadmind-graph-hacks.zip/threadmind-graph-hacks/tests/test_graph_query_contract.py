"""Unit-level contract checks for graph query construction and result mapping.

These tests do not execute Cypher against a database. Use scripts/live_smoke.py for
live FalkorDB integration verification.
"""
from __future__ import annotations

import sys
import types

import pytest

try:  # Allow source-only unit tests when optional runtime dependencies are absent.
    import falkordb  # noqa: F401
except ImportError:
    fallback = types.ModuleType("falkordb")
    fallback.FalkorDB = object  # type: ignore[attr-defined]
    sys.modules["falkordb"] = fallback

from graph_service import GraphService  # noqa: E402


class FakeResult:
    def __init__(self, rows):
        self.result_set = rows


class FakeGraph:
    def __init__(self, rows):
        self.rows = rows
        self.last_query = ""
        self.last_params = {}
        self.queries = []

    def query(self, query, params=None):
        self.last_query = query
        self.last_params = params or {}
        self.queries.append((query, self.last_params))
        return FakeResult(self.rows)


def test_downstream_impact_uses_reverse_multihop_traversal_and_maps_rows():
    service = GraphService.__new__(GraphService)
    service.graph = FakeGraph([
        ["T3", "Build UI", "todo", 1, True, ["Graph is source of truth"]],
        ["T4", "Create demo", "todo", 2, False, []],
    ])

    impact = service.get_downstream_impact("T2")

    assert "(downstream:Task)-[:DEPENDS_ON*1..]->(target:Task" in service.graph.last_query
    assert "OPTIONAL MATCH (d:Decision)-[:AFFECTS]->(downstream)" in service.graph.last_query
    assert "ready_if_target_done" in service.graph.last_query
    assert service.graph.last_params == {"task_id": "T2"}
    assert impact == [
        {"id": "T3", "title": "Build UI", "status": "todo", "distance": 1, "ready_if_target_done": True, "linked_decisions": ["Graph is source of truth"]},
        {"id": "T4", "title": "Create demo", "status": "todo", "distance": 2, "ready_if_target_done": False, "linked_decisions": []},
    ]


def test_downstream_impact_handles_empty_results():
    service = GraphService.__new__(GraphService)
    service.graph = FakeGraph([])
    assert service.get_downstream_impact("T1") == []


def test_add_task_rejects_unknown_dependency_before_creating_task():
    service = GraphService.__new__(GraphService)
    service.graph = FakeGraph([])
    with pytest.raises(ValueError, match="Unknown prerequisite task ID"):
        service.add_task("Draft README", "Write setup notes", "high", "Manish", "2026-10-18", ["NO-SUCH-TASK"])
    assert not any("CREATE (t:Task" in query for query, _ in service.graph.queries)


def test_add_decision_rejects_unknown_task_before_creating_decision():
    service = GraphService.__new__(GraphService)
    service.graph = FakeGraph([])
    with pytest.raises(ValueError, match="unknown task ID"):
        service.add_decision("API choice", "Use graph storage", ["NO-SUCH-TASK"])
    assert not any("CREATE (d:Decision" in query for query, _ in service.graph.queries)


def test_add_task_rejects_invalid_priority_without_database_access():
    service = GraphService.__new__(GraphService)
    service.graph = FakeGraph([])
    with pytest.raises(ValueError, match="Priority must be"):
        service.add_task("Draft README", "Write setup notes", "urgent-ish", "Manish", "2026-10-18", [])
    assert service.graph.queries == []
