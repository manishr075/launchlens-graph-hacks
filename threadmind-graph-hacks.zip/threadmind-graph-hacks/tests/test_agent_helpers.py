"""Small unit tests for deterministic answer routing using a fake graph service."""
from agent import deterministic_answer


class FakeService:
    def list_tasks(self):
        return [
            {"id": "T1", "title": "Define scope", "description": "Finalize scope", "status": "done", "priority": "high", "owner": "M", "due_date": "2026-10-18", "dependencies": []},
            {"id": "T2", "title": "Build graph", "description": "Write queries", "status": "in_progress", "priority": "critical", "owner": "M", "due_date": "2026-10-18", "dependencies": [{"id": "T1", "title": "Define scope", "status": "done"}]},
            {"id": "T3", "title": "Build UI", "description": "Create UI", "status": "todo", "priority": "high", "owner": "M", "due_date": "2026-10-18", "dependencies": [{"id": "T2", "title": "Build graph", "status": "in_progress"}]},
        ]

    def get_ready_tasks(self):
        return [{"id": "T2", "title": "Build graph", "description": "Write queries", "status": "in_progress", "priority": "critical", "owner": "M", "due_date": "2026-10-18", "dependency_count": 1}]

    def get_blocked_tasks(self):
        return [{"id": "T3", "title": "Build UI", "status": "todo", "blockers": ["Build graph"]}]

    def get_blockers_for_task(self, task_id):
        if task_id == "T3":
            return [{"id": "T2", "title": "Build graph", "status": "in_progress", "distance": 1}]
        return []

    def get_downstream_impact(self, task_id):
        if task_id == "T2":
            return [
                {"id": "T3", "title": "Build UI", "status": "todo", "distance": 1, "ready_if_target_done": True, "linked_decisions": ["Graph is source of truth"]},
            ]
        return []

    def list_decisions(self):
        return [{"id": "D1", "title": "Graph is source of truth", "details": "Use graph edges.", "created_at": "2026-10-18", "affected_tasks": ["Build graph", "Build UI"]}]

    def counts(self):
        return {"tasks": 3, "decisions": 1, "dependencies": 2, "decision_links": 2}


def test_next_action_uses_ready_graph_result():
    answer, _ = deterministic_answer("What should I do next?", FakeService())
    assert "Build graph" in answer
    assert "all prerequisite tasks are marked done" in answer


def test_blocker_question_mentions_upstream_task():
    answer, _ = deterministic_answer("Why is Build UI blocked?", FakeService())
    assert "Build graph" in answer
    assert "unfinished prerequisites" in answer


def test_decision_question_retrieves_linked_decision():
    answer, _ = deterministic_answer("What decision should I remember?", FakeService())
    assert "Graph is source of truth" in answer


def test_impact_question_traces_downstream_task_and_related_decision():
    answer, context = deterministic_answer("What gets unblocked if T2 is done?", FakeService())
    assert "Build UI" in answer
    assert "1 relationship hop" in answer
    assert "would be ready immediately" in answer
    assert "Graph is source of truth" in answer
    assert context["impact_task"]["id"] == "T2"
