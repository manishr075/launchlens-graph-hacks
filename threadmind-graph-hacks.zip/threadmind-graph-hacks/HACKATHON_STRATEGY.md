# Graph Hacks 2026 — Strategy, design, and honest verification status

## 1. Official event findings

- **Event:** Graph Hacks: Context for AI Agents, organized by WeMakeDevs with FalkorDB.
- **Window:** October 15, 2026, 12:01 AM IST through October 18, 2026, 11:59 PM IST.
- **Team size:** solo or up to four participants.
- **Required technology:** FalkorDB must be the primary graph database and support a central product behavior. The organizers explicitly say a graph used only for visualization does not qualify.
- **Tracks:** Agents That Act on Connected Data; Agent Memory and Coordination; Company Brain.
- **Required artifacts:** public source repository, README with setup and graph model, the Cypher queries/algorithms used, demo video, deployment or complete local setup, and selected track.
- **Allowed:** public, synthetic, or owned data; frameworks and AI coding assistants are allowed, with AI assistance disclosed.
- **Eligibility risk:** participant must understand and verify the submission. A wholly AI-generated project without meaningful participant contribution and technical understanding may be rejected.

The official current event page gives track-specific focus areas and submission rules. I did not find a published numerical judging rubric for this event, so none is claimed here. The rules say the main project and its FalkorDB implementation must be new work completed during the event; general libraries, templates, and infrastructure may be reused. Track choice and scoring below are recommendations, not official judging scores.

## 2. Previous-project signals (not a promise of judging outcomes)

The official WeMakeDevs HackFrost 2024 archive lists winning entries with direct, demonstrable workflows, such as VaChart for finding vacant train seats after chart preparation, automated model-drift detection, and an AI-powered disaster-relief information platform. These older winners are not evidence of the current Graph Hacks rubric, but they reinforce a sensible product strategy: solve one identifiable problem and make the result visible in a short demo. Graph Hacks has its own graph-specific eligibility rule, which takes priority.

## 3. Five ideas ranked with a risk-adjusted scorecard

The following scores are estimates (0–10). Weighted total = sum(score × criterion weight) / 10. Weights are problem impact 25%, originality 20%, technical depth/required-tech use 20%, feasibility 15%, UX/demo 10%, validation 10%.

| Rank | Idea | Impact /10 (25%) | Originality /10 (20%) | Technical /10 (20%) | Feasibility /10 (15%) | UX /10 (10%) | Validation /10 (10%) | Weighted total /100 |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | **ThreadMind — explainable dependency and decision impact planner** | 7.5 | 7.0 | 8.5 | 9.5 | 8.5 | 8.0 | **80.5** |
| 2 | SupplyGraph — trace how a public package vulnerability propagates through dependencies | 9.0 | 8.5 | 9.0 | 4.0 | 7.0 | 6.0 | 76.5 |
| 3 | IncidentPath — graph-backed alert correlation and root-cause paths across services | 8.5 | 8.0 | 8.5 | 5.5 | 7.5 | 6.5 | 76.5 |
| 4 | Persistent agent memory that detects conflicts and traces which facts support a plan | 8.0 | 7.5 | 8.0 | 7.0 | 8.0 | 6.5 | 76.0 |
| 5 | DecisionLineage — link policies, project decisions, and source evidence for audits | 8.0 | 8.0 | 8.5 | 5.5 | 7.0 | 5.5 | 73.75 |

### Why ThreadMind wins under the actual constraints

Its weighted score benefits from feasibility and direct use of FalkorDB. The other ideas potentially address larger problems but require external data, domain-specific validation, complex source ingestion, or integrations that cannot be verified safely inside the remaining build window. This is a risk-adjusted execution decision, not a claim that ThreadMind has the largest theoretical impact.

## 4. Product definition

- **Name:** ThreadMind — Graph-Powered Project Teammate.
- **Pitch:** Know what to do next—and what your work will unblock—with an explainable project graph.
- **Primary user:** student project, hackathon, and small engineering teams whose tasks have prerequisites and whose decisions need to be recalled later.
- **Problem:** a flat task list shows status but obscures multi-hop blockers, downstream impact, and the decisions that shaped a task.
- **Differentiator:** an explainable “unblock impact” query that reverses dependency paths to show which downstream tasks are affected, their graph distance, connected decision memory, and whether each task would become ready immediately or still needs another prerequisite. This avoids wrongly claiming that every downstream task becomes ready at once.
- **Smallest convincing workflow:** ask what to do next → query live FalkorDB graph → explain why the selected task is ready → inspect a blocker or downstream impact → update task status → query again and show that the result changes.
- **Primary track:** **Agents That Act on Connected Data**. This is the strongest fit because core behavior is graph-based recommendation, multi-hop reasoning, and an action through task state updates. Track 02 is plausible for decision memory, but the current prototype does not coordinate multiple agents, so do not claim that capability.

## 5. Architecture and technology decisions

```mermaid
flowchart LR
  U[User] --> UI[Streamlit UI]
  UI --> A[Intent router and grounded agent]
  A --> Q[Parameterized Cypher queries]
  Q <--> F[(FalkorDB: source of truth)]
  F --> E[Inspectable graph evidence]
  A -. optional .-> L[OpenAI synthesis API]
```

- **Python + Streamlit:** fastest route to an interactive single-user workflow with low setup burden.
- **FalkorDB + Cypher:** stores project, task, decision nodes and the `HAS_TASK`, `DEPENDS_ON`, and `AFFECTS` edges. The readiness, multi-hop blocker, downstream impact, and decision recall features depend on graph traversals.
- **Optional OpenAI API:** not required. Deterministic routing derives its recommendation from retrieved graph results. When configured, the LLM only synthesizes the retrieved evidence; it is not described as an ML model trained for this project.
- **Synthetic demo data:** avoids private-data issues and makes the demo reproducible.
- **No deployment requirement beyond complete local setup:** the official rules allow local setup instructions when no live deployment is available, but a demo video remains required.

## 6. Validation plan

### Measurable success criteria for the prototype

Use the same six-task synthetic graph each time. The smoke test checks five outcomes against known graph structure:

1. sample task data exists;
2. the ready-task query includes T2 while T1 is done and T2 is in progress;
3. tracing T6 reveals unfinished upstream tasks T2, T3, and T4;
4. reverse impact analysis of T2 finds downstream tasks T3, T4, and T6 and correctly distinguishes T3 as immediately ready from T4/T6 as later in the chain;
5. decision recall returns decisions connected to tasks.

The target is **5/5 live smoke checks passing** on FalkorDB. This is a correctness target for the demo fixture, not user-impact or speed evidence. No user study, time-saved claim, or production benchmark has been conducted.

### Verification status at archive preparation

- Python compilation: passed.
- Automated unit tests for agent routing, impact-answer formatting, and query-construction/result mapping: **9 passed**.
- Full runtime/UI verification: **not completed in this environment**; `streamlit` and `falkordb` dependencies were absent, Docker was not installed, and dependency download attempts could not resolve the package index.
- Live Cypher smoke test: prepared as `scripts/live_smoke.py`, **not executed here**. Run it on a machine with a live FalkorDB instance before claiming integration success.
- Deployment, public repository, demo video, and participant validation: not created/verified here.

## 7. Risks and mitigations

| Risk | Mitigation before submission |
|---|---|
| Cypher behavior differs from expected in real FalkorDB | Run `python scripts/live_smoke.py --reset` against a disposable demo graph and fix any failures. |
| Product appears like a generic task chatbot | Lead with the downstream-impact query and show the exact `DEPENDS_ON`/`AFFECTS` evidence. |
| No evidence of actual user need | Ask two classmates with current team projects to try the core workflow; report their feedback accurately, or state validation was not done. |
| LLM answer invents context | Keep graph-grounded deterministic mode as default; optional synthesis is constrained to graph evidence and must gracefully fall back. |
| Fake/unfinished submission links | Fill repository and YouTube URL fields only after creating and testing real links. |
| Participant cannot explain generated code | Read `graph_service.py`, `agent.py`, and `queries.cypher`; be able to explain edge direction, readiness logic, and reverse traversal. |

## 8. What should be shown in the demo

1. Ask for the next task; show the graph-derived result.
2. Show that T6 is blocked through a chain, not just one direct edge.
3. Ask what gets unblocked if T2 is done; show T3, T4, and T6 plus any linked decisions.
4. Update a task's state and ask again to demonstrate persisted state.
5. Show the actual Cypher used and explain why removing FalkorDB removes these features.

Do not record until this exact workflow has passed on the local running app.

## 9. Reference links

- [Official Graph Hacks event page](https://www.wemakedevs.org/hackathons/falkordb)
- [Official Graph Hacks rules](https://www.wemakedevs.org/hackathons/falkordb/rules)
- [Official FalkorDB Getting Started guide](https://docs.falkordb.com/getting-started/)
- [Official FalkorDB Python client](https://github.com/FalkorDB/falkordb-py)
- [Official WeMakeDevs HackFrost 2024 archive of winning projects](https://archive.wemakedevs.org/hackathons/hackfrost24/projects)
