from __future__ import annotations

import json
import os

import streamlit as st
from dotenv import load_dotenv

from agent import answer_question
from graph_service import GraphService

load_dotenv()
st.set_page_config(page_title="ThreadMind | Graph-powered project teammate", page_icon="🧠", layout="wide")

st.markdown(
    """
    <style>
      .block-container {max-width: 1240px; padding-top: 1.6rem; padding-bottom: 3rem;}
      div[data-testid="stMetric"] {background: rgba(128,128,128,.07); border: 1px solid rgba(128,128,128,.18); padding: 14px 16px; border-radius: 14px;}
      .tm-subtitle {color: #777; margin-top: -12px; margin-bottom: 20px;}
      .tm-chip {display:inline-block; border:1px solid rgba(128,128,128,.25); border-radius:999px; padding:3px 10px; margin:2px; font-size:.82rem;}
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_service() -> GraphService:
    return GraphService()


st.title("🧠 ThreadMind")
st.markdown("**A project teammate that remembers relationships, not just text.**")
st.markdown('<p class="tm-subtitle">Trace blockers • recover decisions • recommend the next useful action</p>', unsafe_allow_html=True)

try:
    service = get_service()
    service.wait_until_ready()
    seeded = service.ensure_demo_data()
except Exception as exc:
    st.error("ThreadMind cannot reach FalkorDB yet.")
    st.code(str(exc))
    st.markdown("**Start locally:** open a terminal in the project folder and run `docker compose up -d falkordb`, then `pip install -r requirements.txt` and `streamlit run app.py`.")
    st.markdown("FalkorDB Browser, when available locally: [http://localhost:3000](http://localhost:3000)")
    st.stop()

if seeded:
    st.toast("Created synthetic demo graph in FalkorDB", icon="✅")

counts = service.counts()
tasks = service.list_tasks()
ready = service.get_ready_tasks()
blocked = service.get_blocked_tasks()
decisions = service.list_decisions()

with st.sidebar:
    st.header("Graph status")
    st.success(f"Connected · `{os.getenv('FALKORDB_GRAPH', 'threadmind')}`")
    st.caption(f"FalkorDB endpoint: {os.getenv('FALKORDB_HOST', 'localhost')}:{os.getenv('FALKORDB_PORT', '6379')}")
    st.metric("Graph nodes", counts["tasks"] + counts["decisions"] + 1)
    st.metric("Relationships", counts["dependencies"] + counts["decision_links"] + counts["tasks"])
    st.caption("Synthetic data is used by default. No private project data is loaded.")
    st.divider()
    st.markdown("**Submission track**")
    st.write("Agents That Act on Connected Data")
    st.caption("Optional OpenAI synthesis is enabled only when OPENAI_API_KEY is configured.")
    if st.button("Reset local demo graph", help="Deletes every node in the configured ThreadMind graph and recreates the fictional sample."):
        st.session_state["confirm_reset"] = True
    if st.session_state.get("confirm_reset"):
        st.warning("This clears the configured graph before recreating sample data.")
        col_a, col_b = st.columns(2)
        with col_a:
            if st.button("Confirm reset", type="primary"):
                service.reset_demo_graph()
                st.session_state["confirm_reset"] = False
                st.session_state.pop("agent_answer", None)
                st.rerun()
        with col_b:
            if st.button("Cancel"):
                st.session_state["confirm_reset"] = False
                st.rerun()

metric_cols = st.columns(4)
metric_cols[0].metric("Tasks", counts["tasks"])
metric_cols[1].metric("Completed", sum(1 for t in tasks if t["status"] == "done"))
metric_cols[2].metric("Ready now", len(ready))
metric_cols[3].metric("Dependency-blocked", len(blocked))

agent_tab, tasks_tab, decisions_tab, graph_tab = st.tabs(["Ask ThreadMind", "Task board", "Decision memory", "Graph evidence"])

with agent_tab:
    st.subheader("Ask a question about this project")
    st.write("Answers are grounded in live graph queries. Try a suggested prompt or ask your own question.")
    suggestions = [
        "What should I work on next?",
        "What is blocked and why?",
        "What gets unblocked if T2 is done?",
    ]
    prompt_cols = st.columns(3)
    for i, prompt in enumerate(suggestions):
        if prompt_cols[i].button(prompt, key=f"suggest_{i}", use_container_width=True):
            st.session_state["agent_question"] = prompt
    with st.form("ask_form", clear_on_submit=False):
        question = st.text_input("Your question", key="agent_question", placeholder="e.g. Why is Create a reproducible demo blocked?")
        ask = st.form_submit_button("Ask the graph", type="primary")
    if ask and question.strip():
        with st.spinner("Traversing task and decision relationships…"):
            answer, context, mode = answer_question(question.strip(), service)
        st.session_state["agent_answer"] = {"question": question.strip(), "answer": answer, "context": context, "mode": mode}
    result = st.session_state.get("agent_answer")
    if result:
        st.markdown("#### ThreadMind's answer")
        st.caption(result["mode"])
        st.markdown(result["answer"])
        with st.expander("Inspect the exact graph evidence retrieved"):
            st.json(result["context"])
    else:
        st.info("Start with **What should I work on next?** The agent will query the current graph and explain its recommendation.")

with tasks_tab:
    st.subheader("Project task board")
    st.caption("Readiness is calculated from `DEPENDS_ON` relationships in FalkorDB. Tasks with unfinished prerequisites are not recommended as ready.")
    status_labels = {"todo": "To do", "in_progress": "In progress", "blocked": "Blocked", "done": "Done"}
    for status, title in [("in_progress", "In progress"), ("todo", "To do"), ("blocked", "Blocked"), ("done", "Done")]:
        section = [t for t in tasks if t["status"] == status]
        with st.expander(f"{title} · {len(section)}", expanded=(status in ("in_progress", "todo"))):
            if not section:
                st.caption("No tasks here.")
            for task in section:
                with st.container(border=True):
                    left, right = st.columns([4, 1])
                    left.markdown(f"**{task['title']}**  `{' · '.join([task['id'], task['priority'].upper(), task['owner']])}`")
                    left.write(task["description"])
                    deps = task["dependencies"]
                    if deps:
                        left.caption("Depends on: " + ", ".join(f"{d['title']} [{d['status']}]" for d in deps))
                    else:
                        left.caption("No prerequisites")
                    right.caption(f"Due {task['due_date']}")

    st.divider()
    st.markdown("#### Update a task")
    task_lookup = {f"{t['id']} — {t['title']}": t["id"] for t in tasks}
    with st.form("update_task_form"):
        chosen_task_label = st.selectbox("Task", list(task_lookup))
        new_status = st.selectbox("New status", ["todo", "in_progress", "blocked", "done"], format_func=lambda s: status_labels[s])
        update_submit = st.form_submit_button("Save status")
    if update_submit:
        try:
            service.update_task_status(task_lookup[chosen_task_label], new_status)
            st.success("Task status updated in FalkorDB.")
            st.rerun()
        except Exception as exc:
            st.error(str(exc))

    with st.expander("Add a task"):
        with st.form("add_task_form"):
            new_title = st.text_input("Title")
            new_description = st.text_area("Description")
            c1, c2 = st.columns(2)
            new_priority = c1.selectbox("Priority", ["critical", "high", "medium", "low"], index=1)
            new_owner = c2.text_input("Owner", value="Manish")
            new_due = st.date_input("Due date")
            dependency_labels = st.multiselect("Must be finished first", list(task_lookup))
            add_submit = st.form_submit_button("Create graph task")
        if add_submit:
            try:
                new_id = service.add_task(new_title, new_description, new_priority, new_owner, new_due.isoformat(), [task_lookup[x] for x in dependency_labels])
                st.success(f"Created {new_id} and its graph relationships.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))

with decisions_tab:
    st.subheader("Decision memory")
    st.write("Decisions are stored as graph nodes and linked to every task they affect using `AFFECTS` relationships.")
    if decisions:
        for decision in decisions:
            with st.container(border=True):
                st.markdown(f"**{decision['title']}**  `{decision['id']}`")
                st.write(decision["details"])
                st.caption("Affects: " + ", ".join(decision["affected_tasks"]))
    else:
        st.info("No decisions yet. Add a decision below and link it to a task.")
    with st.expander("Record a decision"):
        with st.form("decision_form"):
            decision_title = st.text_input("Decision title")
            decision_details = st.text_area("What was decided and why?")
            affected_labels = st.multiselect("Tasks affected", list(task_lookup))
            save_decision = st.form_submit_button("Save decision to FalkorDB")
        if save_decision:
            try:
                decision_id = service.add_decision(decision_title, decision_details, [task_lookup[x] for x in affected_labels])
                st.success(f"Saved decision {decision_id} and linked it to the selected tasks.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))

with graph_tab:
    st.subheader("What makes this a graph application?")
    st.write("The agent's main behavior depends on traversing typed relationships. The following rows come directly from FalkorDB.")
    relationships = service.list_relationships()
    st.markdown("**Task dependency edges** — `(Task)-[:DEPENDS_ON]->(Prerequisite Task)`")
    st.caption("ThreadMind also traverses these paths in reverse to calculate downstream impact: which unfinished tasks depend on a selected task.")
    if relationships["dependencies"]:
        st.dataframe(relationships["dependencies"], use_container_width=True, hide_index=True)
    else:
        st.caption("No dependency edges yet.")
    st.markdown("**Decision memory edges** — `(Decision)-[:AFFECTS]->(Task)`")
    if relationships["decision_links"]:
        st.dataframe(relationships["decision_links"], use_container_width=True, hide_index=True)
    else:
        st.caption("No decision edges yet.")
    st.markdown("**Core graph logic**")
    st.code(
        "MATCH (p:Project)-[:HAS_TASK]->(t:Task)\n"
        "WHERE t.status IN ['todo', 'in_progress']\n"
        "OPTIONAL MATCH (t)-[:DEPENDS_ON]->(dep:Task)\n"
        "WITH t, collect(dep) AS deps\n"
        "WHERE all(dep IN deps WHERE dep.status = 'done')\n"
        "RETURN t.title, t.status, size(deps) AS prerequisites",
        language="cypher",
    )
    st.caption("If FalkorDB is removed, the readiness query, dependency-path explanations, and connected decision retrieval cannot run. There is no alternate local task database.")

st.divider()
st.caption("ThreadMind · Graph Hacks 2026 · Synthetic data · FalkorDB is the system of record")
