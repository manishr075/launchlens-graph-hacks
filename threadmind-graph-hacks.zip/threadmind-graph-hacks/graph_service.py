"""FalkorDB persistence and graph queries for ThreadMind."""
from __future__ import annotations

import os
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from falkordb import FalkorDB

PROJECT_ID = "threadmind-demo"
GRAPH_NAME = os.getenv("FALKORDB_GRAPH", "threadmind")

SAMPLE_TASKS = [
    {
        "id": "T1", "title": "Define the project scope", "description": "Agree on the smallest useful end-to-end demo.",
        "status": "done", "priority": "high", "owner": "Manish", "due_date": "2026-10-18",
    },
    {
        "id": "T2", "title": "Implement graph-backed task reasoning", "description": "Query dependency paths and find tasks that are truly ready.",
        "status": "in_progress", "priority": "critical", "owner": "Manish", "due_date": "2026-10-18",
    },
    {
        "id": "T3", "title": "Build the agent interface", "description": "Let a user ask what to do next and inspect the graph evidence.",
        "status": "todo", "priority": "high", "owner": "Manish", "due_date": "2026-10-18",
    },
    {
        "id": "T4", "title": "Create a reproducible demo", "description": "Seed synthetic project data and demonstrate a blocker changing state.",
        "status": "todo", "priority": "medium", "owner": "Manish", "due_date": "2026-10-18",
    },
    {
        "id": "T5", "title": "Prepare synthetic example data", "description": "Use fictional tasks and decisions rather than private project data.",
        "status": "done", "priority": "medium", "owner": "Manish", "due_date": "2026-10-18",
    },
    {
        "id": "T6", "title": "Record and submit the demo", "description": "Show task readiness, dependency tracing, and persistent decisions.",
        "status": "todo", "priority": "critical", "owner": "Manish", "due_date": "2026-10-18",
    },
]

SAMPLE_DEPENDENCIES = [("T2", "T1"), ("T3", "T2"), ("T4", "T3"), ("T6", "T4"), ("T6", "T5")]

SAMPLE_DECISIONS = [
    {
        "id": "D1", "title": "Use FalkorDB as the source of truth",
        "details": "Task readiness and blocker explanations must be derived from graph relationships, not a separate JSON task store.",
        "affected_tasks": ["T2", "T3", "T4", "T6"],
    },
    {
        "id": "D2", "title": "Keep the demo runnable without an LLM key",
        "details": "Use deterministic graph-grounded answers by default; enable optional natural-language synthesis only when an API key is configured.",
        "affected_tasks": ["T3", "T6"],
    },
]


class GraphService:
    def __init__(self) -> None:
        self.host = os.getenv("FALKORDB_HOST", "localhost")
        self.port = int(os.getenv("FALKORDB_PORT", "6379"))
        self.password = os.getenv("FALKORDB_PASSWORD") or None
        self.db = FalkorDB(host=self.host, port=self.port, password=self.password)
        self.graph = self.db.select_graph(GRAPH_NAME)

    def query(self, cypher: str, params: dict[str, Any] | None = None) -> list[list[Any]]:
        """Run a parameterized Cypher query against FalkorDB."""
        return self.graph.query(cypher, params or {}).result_set

    def wait_until_ready(self, timeout_seconds: int = 30) -> None:
        deadline = time.monotonic() + timeout_seconds
        last_error: Exception | None = None
        while time.monotonic() < deadline:
            try:
                rows = self.query("RETURN 1 AS ok")
                if rows and rows[0][0] == 1:
                    return
            except Exception as exc:  # database may still be starting
                last_error = exc
            time.sleep(0.5)
        raise ConnectionError(
            f"Could not connect to FalkorDB at {self.host}:{self.port}. "
            "Start the database with `docker compose up -d falkordb`. "
            f"Last error: {last_error}"
        )

    def ensure_demo_data(self) -> bool:
        """Seed synthetic data only when this graph contains no Project nodes.

        Returns True when seed data was added, otherwise False.
        """
        existing = self.query("MATCH (p:Project {id: $id}) RETURN p.id", {"id": PROJECT_ID})
        if existing:
            return False

        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.query(
            "CREATE (p:Project {id: $id, name: $name, description: $description, created_at: $created_at})",
            {
                "id": PROJECT_ID,
                "name": "ThreadMind Demo Project",
                "description": "Synthetic hackathon project data for graph-grounded planning.",
                "created_at": now,
            },
        )
        for task in SAMPLE_TASKS:
            props = {**task, "updated_at": now}
            self.query(
                "CREATE (t:Task {id: $id, title: $title, description: $description, status: $status, "
                "priority: $priority, owner: $owner, due_date: $due_date, updated_at: $updated_at})",
                props,
            )
            self.query(
                "MATCH (p:Project {id: $project_id}), (t:Task {id: $task_id}) "
                "CREATE (p)-[:HAS_TASK]->(t)",
                {"project_id": PROJECT_ID, "task_id": task["id"]},
            )

        for task_id, dependency_id in SAMPLE_DEPENDENCIES:
            self.query(
                "MATCH (t:Task {id: $task_id}), (d:Task {id: $dependency_id}) "
                "CREATE (t)-[:DEPENDS_ON]->(d)",
                {"task_id": task_id, "dependency_id": dependency_id},
            )

        for decision in SAMPLE_DECISIONS:
            self.query(
                "CREATE (d:Decision {id: $id, title: $title, details: $details, created_at: $created_at})",
                {"id": decision["id"], "title": decision["title"], "details": decision["details"], "created_at": now},
            )
            for task_id in decision["affected_tasks"]:
                self.query(
                    "MATCH (d:Decision {id: $decision_id}), (t:Task {id: $task_id}) "
                    "CREATE (d)-[:AFFECTS]->(t)",
                    {"decision_id": decision["id"], "task_id": task_id},
                )
        return True

    def get_project(self) -> dict[str, Any]:
        rows = self.query("MATCH (p:Project {id: $id}) RETURN p.id, p.name, p.description", {"id": PROJECT_ID})
        if not rows:
            return {"id": PROJECT_ID, "name": "ThreadMind", "description": "Graph-grounded project teammate"}
        return {"id": rows[0][0], "name": rows[0][1], "description": rows[0][2]}

    def list_tasks(self) -> list[dict[str, Any]]:
        rows = self.query(
            "MATCH (p:Project {id: $project_id})-[:HAS_TASK]->(t:Task) "
            "RETURN t.id, t.title, t.description, t.status, t.priority, t.owner, t.due_date, t.updated_at "
            "ORDER BY t.id",
            {"project_id": PROJECT_ID},
        )
        tasks = []
        for row in rows:
            task = {
                "id": row[0], "title": row[1], "description": row[2], "status": row[3],
                "priority": row[4], "owner": row[5], "due_date": row[6], "updated_at": row[7],
            }
            task["dependencies"] = self.get_direct_dependencies(task["id"])
            tasks.append(task)
        return tasks

    def get_direct_dependencies(self, task_id: str) -> list[dict[str, Any]]:
        rows = self.query(
            "MATCH (t:Task {id: $task_id})-[:DEPENDS_ON]->(d:Task) "
            "RETURN d.id, d.title, d.status ORDER BY d.id",
            {"task_id": task_id},
        )
        return [{"id": r[0], "title": r[1], "status": r[2]} for r in rows]

    def get_ready_tasks(self) -> list[dict[str, Any]]:
        """Let FalkorDB traverse DEPENDS_ON to find unfinished, unblocked tasks."""
        rows = self.query(
            "MATCH (p:Project {id: $project_id})-[:HAS_TASK]->(t:Task) "
            "WHERE t.status IN ['todo', 'in_progress'] "
            "OPTIONAL MATCH (t)-[:DEPENDS_ON]->(dep:Task) "
            "WITH t, collect(dep) AS deps "
            "WHERE all(dep IN deps WHERE dep.status = 'done') "
            "RETURN t.id, t.title, t.description, t.status, t.priority, t.owner, t.due_date, size(deps) AS dependency_count",
            {"project_id": PROJECT_ID},
        )
        priority_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        tasks = [
            {"id": r[0], "title": r[1], "description": r[2], "status": r[3], "priority": r[4],
             "owner": r[5], "due_date": r[6], "dependency_count": r[7]}
            for r in rows
        ]
        tasks.sort(key=lambda t: (0 if t["status"] == "in_progress" else 1, priority_rank.get(t["priority"], 9), t["due_date"] or ""))
        return tasks

    def get_blocked_tasks(self) -> list[dict[str, Any]]:
        """Find unfinished tasks with any unfinished prerequisite on a graph path."""
        rows = self.query(
            "MATCH (p:Project {id: $project_id})-[:HAS_TASK]->(t:Task) "
            "WHERE t.status IN ['todo', 'in_progress'] "
            "MATCH (t)-[:DEPENDS_ON*1..]->(dep:Task) "
            "WHERE dep.status <> 'done' "
            "RETURN t.id, t.title, t.status, collect(DISTINCT dep.title) AS blockers "
            "ORDER BY t.id",
            {"project_id": PROJECT_ID},
        )
        return [{"id": r[0], "title": r[1], "status": r[2], "blockers": list(r[3] or [])} for r in rows]

    def get_blockers_for_task(self, task_id: str) -> list[dict[str, Any]]:
        rows = self.query(
            "MATCH path=(t:Task {id: $task_id})-[:DEPENDS_ON*1..]->(dep:Task) "
            "WHERE dep.status <> 'done' "
            "RETURN dep.id, dep.title, dep.status, min(length(path)) AS distance "
            "ORDER BY distance",
            {"task_id": task_id},
        )
        return [{"id": r[0], "title": r[1], "status": r[2], "distance": r[3]} for r in rows]

    def get_downstream_impact(self, task_id: str) -> list[dict[str, Any]]:
        """Trace unfinished downstream tasks that depend on this task, at any depth.

        The path direction is intentionally reversed from the prerequisite traversal:
        every returned task has a DEPENDS_ON path leading to the selected task.
        This is the project's explainable "what gets unblocked?" analysis.
        """
        rows = self.query(
            "MATCH path=(downstream:Task)-[:DEPENDS_ON*1..]->(target:Task {id: $task_id}) "
            "WHERE downstream.status <> 'done' AND downstream.id <> target.id "
            "WITH downstream, target, min(length(path)) AS distance "
            "OPTIONAL MATCH (downstream)-[:DEPENDS_ON]->(direct_dep:Task) "
            "WITH downstream, target, distance, collect(direct_dep) AS direct_deps "
            "WITH downstream, target, distance, "
            "(downstream.status IN ['todo', 'in_progress'] AND "
            "all(dep IN direct_deps WHERE dep.status = 'done' OR dep.id = target.id)) AS ready_if_target_done "
            "OPTIONAL MATCH (d:Decision)-[:AFFECTS]->(downstream) "
            "RETURN downstream.id, downstream.title, downstream.status, distance, ready_if_target_done, "
            "collect(DISTINCT d.title) AS linked_decisions "
            "ORDER BY distance, downstream.id",
            {"task_id": task_id},
        )
        return [
            {
                "id": row[0],
                "title": row[1],
                "status": row[2],
                "distance": row[3],
                "ready_if_target_done": bool(row[4]),
                "linked_decisions": list(row[5] or []),
            }
            for row in rows
        ]

    def list_decisions(self) -> list[dict[str, Any]]:
        rows = self.query(
            "MATCH (d:Decision)-[:AFFECTS]->(t:Task) "
            "RETURN d.id, d.title, d.details, d.created_at, collect(DISTINCT t.title) AS affected_tasks "
            "ORDER BY d.created_at DESC",
            {},
        )
        return [{"id": r[0], "title": r[1], "details": r[2], "created_at": r[3], "affected_tasks": list(r[4] or [])} for r in rows]

    def list_relationships(self) -> dict[str, list[dict[str, str]]]:
        dep_rows = self.query(
            "MATCH (t:Task)-[:DEPENDS_ON]->(d:Task) RETURN t.id, t.title, d.id, d.title ORDER BY t.id, d.id"
        )
        affect_rows = self.query(
            "MATCH (d:Decision)-[:AFFECTS]->(t:Task) RETURN d.id, d.title, t.id, t.title ORDER BY d.id, t.id"
        )
        return {
            "dependencies": [{"task_id": r[0], "task": r[1], "dependency_id": r[2], "depends_on": r[3]} for r in dep_rows],
            "decision_links": [{"decision_id": r[0], "decision": r[1], "task_id": r[2], "task": r[3]} for r in affect_rows],
        }

    def update_task_status(self, task_id: str, status: str) -> None:
        allowed = {"todo", "in_progress", "blocked", "done"}
        if status not in allowed:
            raise ValueError(f"Unknown status: {status}")
        if status == "done":
            blockers = self.get_blockers_for_task(task_id)
            if blockers:
                names = ", ".join(item["title"] for item in blockers)
                raise ValueError(f"Cannot mark this task done yet. Finish its prerequisite(s) first: {names}.")
        rows = self.query(
            "MATCH (t:Task {id: $task_id}) SET t.status = $status, t.updated_at = $updated_at RETURN t.id",
            {"task_id": task_id, "status": status, "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds")},
        )
        if not rows:
            raise ValueError("Task not found.")

    def add_task(self, title: str, description: str, priority: str, owner: str, due_date: str, dependencies: list[str]) -> str:
        title = title.strip()
        if not title:
            raise ValueError("Task title is required.")
        if priority not in {"critical", "high", "medium", "low"}:
            raise ValueError("Priority must be critical, high, medium, or low.")

        dependency_ids = list(dict.fromkeys(dependencies))
        if dependency_ids:
            existing_rows = self.query(
                "MATCH (t:Task) WHERE t.id IN $task_ids RETURN t.id",
                {"task_ids": dependency_ids},
            )
            existing_ids = {row[0] for row in existing_rows}
            missing_ids = sorted(set(dependency_ids) - existing_ids)
            if missing_ids:
                raise ValueError("Unknown prerequisite task ID(s): " + ", ".join(missing_ids))

        task_id = "T-" + uuid.uuid4().hex[:7].upper()
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        created = self.query(
            "MATCH (p:Project {id: $project_id}) "
            "CREATE (t:Task {id: $id, title: $title, description: $description, status: 'todo', "
            "priority: $priority, owner: $owner, due_date: $due_date, updated_at: $updated_at}) "
            "CREATE (p)-[:HAS_TASK]->(t) RETURN t.id",
            {"project_id": PROJECT_ID, "id": task_id, "title": title, "description": description,
             "priority": priority, "owner": owner.strip() or "Unassigned", "due_date": due_date, "updated_at": now},
        )
        if not created:
            raise ValueError("Could not create the task. Confirm that the project node exists in FalkorDB.")
        for dependency_id in dependency_ids:
            self.query(
                "MATCH (t:Task {id: $task_id}), (d:Task {id: $dependency_id}) "
                "CREATE (t)-[:DEPENDS_ON]->(d)",
                {"task_id": task_id, "dependency_id": dependency_id},
            )
        return task_id

    def add_decision(self, title: str, details: str, affected_task_ids: list[str]) -> str:
        if not title.strip() or not details.strip():
            raise ValueError("Decision title and details are required.")
        if not affected_task_ids:
            raise ValueError("Link the decision to at least one task to preserve graph context.")

        task_ids = list(dict.fromkeys(affected_task_ids))
        existing_rows = self.query(
            "MATCH (t:Task) WHERE t.id IN $task_ids RETURN t.id",
            {"task_ids": task_ids},
        )
        existing_ids = {row[0] for row in existing_rows}
        missing_ids = sorted(set(task_ids) - existing_ids)
        if missing_ids:
            raise ValueError("Cannot link decision; unknown task ID(s): " + ", ".join(missing_ids))

        decision_id = "D-" + uuid.uuid4().hex[:7].upper()
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        created = self.query(
            "CREATE (d:Decision {id: $id, title: $title, details: $details, created_at: $created_at}) RETURN d.id",
            {"id": decision_id, "title": title.strip(), "details": details.strip(), "created_at": now},
        )
        if not created:
            raise ValueError("Could not create the decision node in FalkorDB.")
        for task_id in task_ids:
            rows = self.query(
                "MATCH (d:Decision {id: $decision_id}), (t:Task {id: $task_id}) "
                "CREATE (d)-[:AFFECTS]->(t) RETURN t.id",
                {"decision_id": decision_id, "task_id": task_id},
            )
            if not rows:
                raise ValueError(f"Could not link decision to task {task_id}.")
        return decision_id

    def counts(self) -> dict[str, int]:
        task_rows = self.query("MATCH (t:Task) RETURN count(t)")
        decision_rows = self.query("MATCH (d:Decision) RETURN count(d)")
        dependency_rows = self.query("MATCH ()-[r:DEPENDS_ON]->() RETURN count(r)")
        affect_rows = self.query("MATCH ()-[r:AFFECTS]->() RETURN count(r)")
        return {
            "tasks": int(task_rows[0][0]) if task_rows else 0,
            "decisions": int(decision_rows[0][0]) if decision_rows else 0,
            "dependencies": int(dependency_rows[0][0]) if dependency_rows else 0,
            "decision_links": int(affect_rows[0][0]) if affect_rows else 0,
        }

    def reset_demo_graph(self) -> None:
        self.query("MATCH (n) DETACH DELETE n")
        self.ensure_demo_data()
