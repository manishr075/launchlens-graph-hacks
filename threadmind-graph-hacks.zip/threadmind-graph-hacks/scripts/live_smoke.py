"""Live FalkorDB smoke test for ThreadMind's graph-dependent workflows.

Run with `python scripts/live_smoke.py --reset` against a disposable ThreadMind graph.
The reset flag deletes all nodes in the configured graph before reseeding sample data.
"""
from __future__ import annotations

import argparse
import sys

from graph_service import GraphService


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete and recreate all data in the configured graph (use only for the demo graph).",
    )
    args = parser.parse_args()

    service = GraphService()
    service.wait_until_ready(timeout_seconds=30)

    if args.reset:
        print("Resetting the configured graph. Ensure it contains only disposable ThreadMind demo data.")
        service.reset_demo_graph()
    else:
        seeded = service.ensure_demo_data()
        if seeded:
            print("Seeded the synthetic ThreadMind demo graph.")

    checks: list[tuple[str, bool, str]] = []

    tasks = {task["id"]: task for task in service.list_tasks()}
    checks.append(("Synthetic task data exists", all(key in tasks for key in ("T2", "T3", "T4", "T6")), f"found {len(tasks)} tasks"))

    ready_ids = {task["id"] for task in service.get_ready_tasks()}
    checks.append(("Graph readiness query", "T2" in ready_ids, f"ready task IDs: {', '.join(sorted(ready_ids)) or '(none)'}"))

    blocker_ids = {item["id"] for item in service.get_blockers_for_task("T6")}
    checks.append(("Multi-hop blocker traversal", {"T2", "T3", "T4"}.issubset(blocker_ids), f"unfinished upstream IDs for T6: {', '.join(sorted(blocker_ids)) or '(none)'}"))

    impact_rows = service.get_downstream_impact("T2")
    impact_by_id = {item["id"]: item for item in impact_rows}
    impact_ids = set(impact_by_id)
    expected_paths = {"T3", "T4", "T6"}.issubset(impact_ids)
    readiness_flags = (
        impact_by_id.get("T3", {}).get("ready_if_target_done") is True
        and impact_by_id.get("T4", {}).get("ready_if_target_done") is False
        and impact_by_id.get("T6", {}).get("ready_if_target_done") is False
    )
    checks.append(("Reverse impact + immediate-vs-later distinction", expected_paths and readiness_flags, f"downstream IDs for T2: {', '.join(sorted(impact_ids)) or '(none)'}; T3 should be immediately ready, T4/T6 remain later in the chain"))

    decisions = service.list_decisions()
    checks.append(("Persistent decision memory", bool(decisions) and any(d["affected_tasks"] for d in decisions), f"retrieved {len(decisions)} linked decisions"))

    for label, passed, detail in checks:
        print(f"{'PASS' if passed else 'FAIL'} | {label} | {detail}")

    failed = [label for label, passed, _ in checks if not passed]
    if failed:
        print("\nSmoke test failed: " + "; ".join(failed), file=sys.stderr)
        print("For a clean disposable graph, rerun with --reset. This clears the configured graph.", file=sys.stderr)
        return 1

    print(f"\nAll {len(checks)} live FalkorDB smoke checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
